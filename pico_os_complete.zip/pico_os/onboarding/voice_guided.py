
from utils.logger import get_logger
import time
class VoiceGuidedOnboarding:
    def __init__(self, tts, audio_io, speaker_verifier, pairing_manager):
        self.tts = tts
        self.audio = audio_io
        self.speaker = speaker_verifier
        self.pairing = pairing_manager
        self.logger = get_logger("Onboarding")
    def run(self):
        steps = [
            "Welcome to Pico. For those who ask. For those who question.",
            "I'm your hands-free voice companion, built on Arduino UNO Q.",
            "First, let's pair your phone. Make sure your phone and I are on the same Wi-Fi network.",
            f"Your device key is {self.pairing.device_key[:4]} ... {self.pairing.device_key[-4:]}.",
            "Now, let's learn your voice. Please say Hey Pico, it's me three times after the beep.",
        ]
        for step in steps:
            self.logger.info(f"ONBOARDING: {step}")
            self.tts.speak(step, audio_io=self.audio)
            time.sleep(1.0)
        for i in range(3):
            self.tts.speak(f"Beep. Sample {i+1} of 3.", audio_io=self.audio)
            time.sleep(1)
            self.speaker.enroll("owner", [b"\x00"*512])
        self.tts.speak("Perfect! I now recognize you.", audio_io=self.audio)
        self.logger.info("Onboarding complete")
