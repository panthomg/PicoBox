
from utils.logger import get_logger
import os
class SearchService:
    def __init__(self, mock=False):
        self.mock = mock
        self.logger = get_logger("Search")
        self.tavily_key = os.getenv("TAVILY_API_KEY")
    def search(self, query, deep=False):
        if self.mock or not self.tavily_key:
            return f"[MOCK SEARCH for '{query}'] Pico is Arduino UNO Q voice assistant, 5m far-field, any AI model. Deep={deep}. (Set TAVILY_API_KEY for real)"
        try:
            from tavily import TavilyClient
            client = TavilyClient(api_key=self.tavily_key)
            result = client.search(query, search_depth="advanced" if deep else "basic", max_results=5)
            return "\n".join([f"- {r['title']}: {r['content'][:300]} ({r['url']})" for r in result.get("results", [])])
        except Exception as e:
            self.logger.warning(f"Tavily fail {e}")
            return self.search(query, deep=False) if not self.mock else f"[MOCK SEARCH {query}]"
