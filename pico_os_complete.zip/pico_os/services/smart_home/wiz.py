
from utils.logger import get_logger
class WizService:
    def __init__(self, mock=True):
        self.mock = mock
        self.logger = get_logger("WiZ")
    def control_lights(self, state):
        self.logger.info(f"[MOCK WiZ] {state}")
        return True
