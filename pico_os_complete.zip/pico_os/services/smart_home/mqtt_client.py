
from utils.logger import get_logger
class MQTTService:
    def __init__(self, mock=True):
        self.mock = mock
        self.logger = get_logger("MQTT")
    def publish(self, topic, payload):
        self.logger.info(f"[MOCK MQTT] {topic} -> {payload}")
        return True
    def control_lights(self, state):
        return self.publish("home/living_room/light/set", "ON" if state=="on" else "OFF")
