
from utils.logger import get_logger
class MatterService:
    def __init__(self, mock=True):
        self.mock = mock
        self.logger = get_logger("Matter")
    def control(self, device, action):
        self.logger.info(f"[MOCK Matter] {device} {action}")
        return True
