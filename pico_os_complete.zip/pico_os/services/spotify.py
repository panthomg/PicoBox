
from utils.logger import get_logger
class SpotifyService:
    def __init__(self, mock=True):
        self.mock = mock
        self.logger = get_logger("Spotify")
    def play(self, query):
        self.logger.info(f"[MOCK SPOTIFY] {query}")
        return True
