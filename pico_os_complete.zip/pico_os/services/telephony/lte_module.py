
from utils.logger import get_logger
class LTEService:
    def __init__(self, mock=True):
        self.mock = mock
        self.logger = get_logger("LTE")
    def make_call(self, number):
        self.logger.info(f"[MOCK LTE] Calling {number}")
        return True
