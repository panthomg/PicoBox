
from utils.logger import get_logger
class VoIPService:
    def __init__(self, mock=True):
        self.mock = mock
        self.logger = get_logger("VoIP")
    def call(self, sip_uri):
        self.logger.info(f"[MOCK VoIP] {sip_uri}")
        return True
