
from utils.logger import get_logger
class AgoraReceptionist:
    def __init__(self, mock=True):
        self.mock = mock
        self.logger = get_logger("Agora")
    def start_receptionist(self):
        self.logger.info("[MOCK Agora] Receptionist started")
        return True
