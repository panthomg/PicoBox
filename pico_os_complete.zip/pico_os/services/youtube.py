
from utils.logger import get_logger
class YouTubeService:
    def __init__(self, mock=True):
        self.mock = mock
        self.logger = get_logger("YouTube")
    def play(self, query):
        self.logger.info(f"[MOCK YOUTUBE] {query}")
        return True
