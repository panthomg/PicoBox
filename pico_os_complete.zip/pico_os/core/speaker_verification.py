
from utils.logger import get_logger
from utils.voiceprint_store import VoiceprintStore
class SpeakerVerifier:
    def __init__(self, config, mock=True):
        self.config = config
        self.mock = mock
        self.logger = get_logger("Speaker")
        self.store = VoiceprintStore(config.get("voiceprints_dir", "data/voiceprints"))
    def enroll(self, user_id, audio_frames):
        self.store.save_profile(user_id, embedding=[0.1,0.2,0.3], samples=len(audio_frames))
        self.logger.info(f"Enrolled {user_id}")
        return True
    def verify(self, audio_frame):
        users = self.store.list_users()
        if users:
            return users[0], 0.9
        return "guest", 0.5
