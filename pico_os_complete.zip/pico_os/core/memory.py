
import json, time
from pathlib import Path
from collections import deque
class ConversationMemory:
    def __init__(self, config):
        self.max_turns = config.get("max_conversation_turns", 20)
        self.file = Path(config.get("long_term_memory_file", "data/memory/long_term.json"))
        self.file.parent.mkdir(parents=True, exist_ok=True)
        self.sessions = {}
        self.long_term = {}
        if self.file.exists():
            try:
                self.long_term = json.loads(self.file.read_text())
            except:
                self.long_term = {}
    def _get_deque(self, user_id):
        if user_id not in self.sessions:
            self.sessions[user_id] = deque(maxlen=self.max_turns)
        return self.sessions[user_id]
    def add_turn(self, user_id, user_text, assistant_text, metadata=None):
        dq = self._get_deque(user_id)
        dq.append({"ts": time.time(),"user": user_text,"assistant": assistant_text,"meta": metadata or {}})
        if user_id not in self.long_term:
            self.long_term[user_id] = {"interactions":0}
        self.long_term[user_id]["interactions"] += 1
        self.file.write_text(json.dumps(self.long_term, indent=2))
    def get_history(self, user_id, n=None):
        dq = self._get_deque(user_id)
        hist = list(dq)[-n:] if n else list(dq)
        messages = []
        for turn in hist:
            messages.append({"role":"user","content": turn["user"]})
            messages.append({"role":"assistant","content": turn["assistant"]})
        return messages
memory = None
def get_memory(config):
    global memory
    if memory is None:
        memory = ConversationMemory(config)
    return memory
