
from utils.logger import get_logger
class SmartInterrupter:
    def __init__(self, config, audio_io, wake_detector):
        self.config = config
        self.audio_io = audio_io
        self.wake_detector = wake_detector
        self.logger = get_logger("Interrupter")
        self.is_speaking = False
        self.interrupted = False
        self.threshold_db = config.get("barge_in_threshold_db", -40)
        self.enabled = config.get("enabled", True)
    def start_speaking(self):
        self.is_speaking = True
        self.interrupted = False
    def stop_speaking(self):
        self.is_speaking = False
    def check_for_barge_in(self, audio_frame_bytes):
        if not self.enabled or not self.is_speaking:
            return False
        import struct, math
        try:
            if isinstance(audio_frame_bytes, bytes):
                fmt = f"{len(audio_frame_bytes)//2}h"
                samples = struct.unpack(fmt, audio_frame_bytes)
            else:
                samples = audio_frame_bytes
            rms = math.sqrt(sum(s*s for s in samples)/len(samples)) if samples else 0
            db = 20*math.log10(rms) if rms>0 else -100
            if db > self.threshold_db:
                self.logger.info(f"Barge-in {db:.1f}dB")
                self.interrupted = True
                self.is_speaking = False
                return True
        except:
            pass
        return False
