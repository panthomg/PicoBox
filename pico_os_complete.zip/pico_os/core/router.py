
from utils.logger import get_logger
import re
class CommandRouter:
    def __init__(self, config):
        self.config = config
        self.logger = get_logger("Router")
        self.think_kws = config.get("think_keywords", ["think"])
        self.search_kws = config.get("search_keywords", ["search"])
        self.think_search_kws = config.get("think_search_keywords", ["search and think"])
    def route(self, text: str):
        t = text.lower().strip()
        for kw in self.think_search_kws:
            if kw in t:
                return "think_and_search", self._strip_trigger(t, kw)
        for kw in self.search_kws:
            if t.startswith(kw) or f" {kw}" in f" {t}":
                return "search", self._strip_trigger(t, kw)
        for kw in self.think_kws:
            if kw in t:
                return "think", self._strip_trigger(t, kw)
        if any(x in t for x in ["turn on","turn off","lights","spotify","play music","youtube"]):
            return "action", t
        return "chat", t
    def _strip_trigger(self, text, trigger):
        pattern = re.compile(re.escape(trigger), re.IGNORECASE)
        cleaned = pattern.sub("", text, count=1).strip(" ,:.-")
        return cleaned if cleaned else text
router = None
def get_router(config):
    global router
    if router is None:
        router = CommandRouter(config)
    return router
