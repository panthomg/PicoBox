
from utils.logger import get_logger
class TextToSpeech:
    def __init__(self, config, mock=False):
        self.config = config
        self.mock = mock
        self.logger = get_logger("TTS")
        self.voice = None
        if not mock:
            try:
                from piper import PiperVoice
                import pathlib
                model_path = config.get("model_path", "models/piper/")
                model_file = pathlib.Path(model_path) / f"{config.get('model','en_US-lessac-medium')}.onnx"
                if not model_file.exists():
                    raise FileNotFoundError(model_file)
                self.voice = PiperVoice.load(str(model_file))
            except Exception as e:
                self.logger.warning(f"Piper mock: {e}")
                self.mock = True
    def synthesize(self, text):
        if self.mock:
            self.logger.info(f"[TTS MOCK] {text}")
            import numpy as np
            pcm = (np.zeros(16000, dtype=np.int16)).tobytes()
            return pcm, 16000, text
        try:
            audio_chunks = []
            for chunk in self.voice.synthesize(text):
                audio_chunks.append(chunk.audio_int16_bytes)
            pcm = b"".join(audio_chunks)
            return pcm, self.voice.config.sample_rate, text
        except Exception as e:
            self.logger.error(f"TTS error {e}")
            return b"", 16000, text
    def speak(self, text, audio_io=None):
        pcm, sr, _ = self.synthesize(text)
        if audio_io:
            audio_io.play_audio(pcm, sample_rate=sr)
        return pcm
