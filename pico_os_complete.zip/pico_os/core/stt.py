
from utils.logger import get_logger
import json
class SpeechToText:
    def __init__(self, config, mock=False):
        self.config = config
        self.mock = mock
        self.logger = get_logger("STT")
        self.model = None
        if not mock:
            try:
                from vosk import Model, KaldiRecognizer
                import os
                model_path = config.get("model_path", "models/vosk-model-small-en-us-0.15")
                if not os.path.exists(model_path):
                    raise FileNotFoundError(model_path)
                self.model = Model(model_path)
                self.recognizer = KaldiRecognizer(self.model, 16000)
            except Exception as e:
                self.logger.warning(f"Vosk mock: {e}")
                self.mock = True
    def transcribe_frame(self, audio_bytes):
        if self.mock:
            return None
        try:
            if self.recognizer.AcceptWaveform(audio_bytes):
                res = json.loads(self.recognizer.Result())
                return res.get("text", "")
            return None
        except:
            return None
    def mock_transcribe_text(self, text):
        return text
