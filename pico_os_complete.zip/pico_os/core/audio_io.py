
import queue, threading, time
class AudioIO:
    def __init__(self, sample_rate=16000, frame_length=512, mock=False):
        self.sample_rate = sample_rate
        self.frame_length = frame_length
        self.mock = mock
        self.input_queue = queue.Queue()
        self.is_recording = False
        from utils.logger import get_logger
        self.logger = get_logger("AudioIO")
        if not mock:
            try:
                import pyaudio
                self.p = pyaudio.PyAudio()
            except Exception as e:
                self.logger.warning(f"PyAudio not available, mock: {e}")
                self.mock = True
                self.p = None
        else:
            self.p = None
    def start(self):
        self.is_recording = True
        if self.mock:
            threading.Thread(target=self._mock_loop, daemon=True).start()
        else:
            self.stream = self.p.open(format=self.p.get_format_from_width(2), channels=1, rate=self.sample_rate, input=True, frames_per_buffer=self.frame_length, stream_callback=self._callback)
            self.stream.start_stream()
    def _callback(self, in_data, frame_count, time_info, status):
        self.input_queue.put(in_data)
        return (None, 0)
    def _mock_loop(self):
        import time
        while self.is_recording:
            self.input_queue.put(b"\x00\x00"*self.frame_length)
            time.sleep(self.frame_length/self.sample_rate)
    def read_frame(self, timeout=1.0):
        try:
            return self.input_queue.get(timeout=timeout)
        except:
            return None
    def play_audio(self, audio_bytes, sample_rate=None):
        if self.mock:
            from utils.logger import get_logger
            get_logger("AudioIO").info(f"[MOCK PLAY] {len(audio_bytes)} bytes")
            return
        try:
            import pyaudio
            p = pyaudio.PyAudio()
            stream = p.open(format=p.get_format_from_width(2), channels=1, rate=sample_rate or self.sample_rate, output=True)
            stream.write(audio_bytes)
            stream.stop_stream(); stream.close(); p.terminate()
        except Exception as e:
            print(f"Playback error: {e}")
    def stop(self):
        self.is_recording = False
