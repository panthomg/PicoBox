
import time, threading, queue
from utils.logger import get_logger
from utils.latency import tracker as latency_tracker
class PicoLifecycle:
    def __init__(self, audio_io, wake_word, speaker_verifier, stt, tts, router, memory, ai_manager, services, interrupter, config):
        self.audio = audio_io
        self.wake = wake_word
        self.speaker = speaker_verifier
        self.stt = stt
        self.tts = tts
        self.router = router
        self.memory = memory
        self.ai = ai_manager
        self.services = services
        self.interrupter = interrupter
        self.config = config
        self.logger = get_logger("PicoOS")
        self.running = False
        self.state = "idle"
        self.command_queue = queue.Queue()
    def start(self):
        self.logger.info("PICO OS STARTING")
        self.audio.start()
        self.running = True
        threading.Thread(target=self._audio_loop, daemon=True).start()
        threading.Thread(target=self._command_loop, daemon=True).start()
        self.logger.info("PICO ready. Say Hey Pico")
        try:
            while self.running:
                time.sleep(0.1)
        except KeyboardInterrupt:
            self.stop()
    def _audio_loop(self):
        buffer = b""
        listening_until = 0
        while self.running:
            frame = self.audio.read_frame(timeout=0.5)
            if not frame:
                continue
            if self.state == "speaking":
                if self.interrupter.check_for_barge_in(frame):
                    self.state = "listening"
                    listening_until = time.time() + 6
                    buffer = b""
                    continue
            if self.state == "idle":
                if self.wake.detect(frame):
                    self.logger.info("WAKE WORD!")
                    latency_tracker.mark("wake_detected")
                    self.state = "listening"
                    listening_until = time.time() + 8
                    self.tts.speak("Yes?", audio_io=self.audio)
                    buffer = b""
            elif self.state == "listening":
                buffer += frame
                if time.time() > listening_until or len(buffer) > 32000:
                    if len(buffer) > 4000:
                        user_id, conf = self.speaker.verify(frame)
                        # In mock, text is injected via queue, so skip
                        self.state = "idle"
                    buffer = b""
    def _command_loop(self):
        while self.running:
            try:
                user_id, text = self.command_queue.get(timeout=1)
            except:
                continue
            latency_tracker.mark("command_received")
            mode, query = self.router.route(text)
            self.logger.info(f"ROUTED {mode} {query}")
            response_text = ""
            try:
                if mode == "search":
                    search_result = self.services["search"].search(query)
                    response_text = self.ai.chat(query, user_id=user_id, context=search_result, mode="search")
                elif mode == "think_and_search":
                    search_result = self.services["search"].search(query, deep=True)
                    response_text = self.ai.chat(query, user_id=user_id, context=search_result, mode="think_and_search")
                elif mode == "think":
                    response_text = self.ai.chat(query, user_id=user_id, mode="think")
                elif mode == "action":
                    response_text = self._handle_action(query, user_id)
                else:
                    response_text = self.ai.chat(query, user_id=user_id, mode="chat")
            except Exception as e:
                self.logger.error(f"AI error {e}")
                response_text = "Sorry, trouble thinking. Try again?"
            self.memory.add_turn(user_id, text, response_text, {"mode": mode})
            self.state = "speaking"
            self.interrupter.start_speaking()
            self.tts.speak(response_text, audio_io=self.audio)
            self.interrupter.stop_speaking()
            self.state = "idle"
    def _handle_action(self, query, user_id):
        q = query.lower()
        if "light" in q:
            if "on" in q:
                self.services["smart_home"].control_lights("on")
                return "Turning the lights on."
            else:
                self.services["smart_home"].control_lights("off")
                return "Turning the lights off."
        if "spotify" in q or "play" in q:
            self.services["spotify"].play(query)
            return f"Playing {query} on Spotify."
        if "youtube" in q:
            self.services["youtube"].play(query)
            return f"Playing {query} on YouTube."
        return "Action integration not fully configured yet."
    def handle_text_input(self, user_id, text):
        if self.wake.detect_text_mock(text):
            for kw in self.wake.config.get("keywords", []):
                if kw.lower() in text.lower():
                    text = text.lower().replace(kw.lower(), "").strip(" ,")
                    break
            if not text:
                return "Yes? I'm listening."
            self.command_queue.put((user_id, text))
            return f"Got it: {text} - thinking..."
        else:
            self.command_queue.put((user_id, text))
            return f"Processing: {text}"
    def stop(self):
        self.running = False
        self.audio.stop()
