
from utils.logger import get_logger
class WakeWordDetector:
    def __init__(self, config, mock=False):
        self.config = config
        self.mock = mock
        self.logger = get_logger("WakeWord")
        self.engine = None
        self._init_engine()
    def _init_engine(self):
        if self.mock:
            self.logger.info("WakeWord MOCK")
            return
        try:
            import pvporcupine, os
            access_key = os.getenv("PICOVOICE_ACCESS_KEY")
            if not access_key:
                raise ValueError("No key")
            self.engine = pvporcupine.create(access_key=access_key, keywords=["porcupine"])
        except Exception as e:
            self.logger.warning(f"Porcupine fail mock: {e}")
            self.mock = True
    def detect(self, pcm_frame):
        if self.mock:
            return False
        try:
            import struct
            if isinstance(pcm_frame, bytes):
                pcm = struct.unpack_from("h"*self.engine.frame_length, pcm_frame)
            else:
                pcm = pcm_frame
            return self.engine.process(pcm) >= 0
        except:
            return False
    def detect_text_mock(self, text: str):
        text = text.lower()
        for kw in self.config.get("keywords", ["hey pico"]):
            if kw.lower() in text:
                return True
        return False
