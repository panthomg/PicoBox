
# PICO OS - Complete Implementation
For those who ask. For those who question.
See main README for architecture. This is the runnable OS.
Quick start: python main.py --mock --text "hey pico think about AI"
Companion: http://localhost:8765
