
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
import time, json
from utils.logger import get_logger
from .models import ChatRequest, PairingRequest, SettingsUpdate
from .pairing import PairingManager
from .websocket_manager import manager as ws_manager

logger = get_logger("Companion")
app = FastAPI(title="PICO Companion", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

pico_core = None
pairing_manager = PairingManager()
start_time = time.time()

@app.get("/", response_class=HTMLResponse)
async def root():
    return '''
<!DOCTYPE html>
<html><head><title>PICO Companion</title><meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{background:#000;color:#fff;font-family:monospace;padding:20px}.board{border:1px dashed #333;padding:15px;margin:10px 0}.dot{width:8px;height:8px;background:#fff;border-radius:50%;display:inline-block;margin:2px}h1{letter-spacing:0.2em}input,button,select{background:#111;color:#fff;border:1px solid #333;padding:10px;font-family:monospace}button:hover{background:#fff;color:#000;cursor:pointer}#log{height:200px;overflow-y:auto;background:#0a0a0a;padding:10px;font-size:12px}</style>
</head><body>
<h1>● PICO COMPANION</h1>
<div class="board"><div>DEVICE: <span id="status">checking...</span></div><div>PROVIDER: <span id="provider">-</span></div><div>BUDGET: <span id="budget">-</span></div><div>UPTIME: <span id="uptime">-</span></div></div>
<div class="board"><h3>CHAT WITH PICO (Remote Mode)</h3><input id="msg" placeholder="Say Hey Pico, ..." style="width:60%"><button onclick="sendChat()">SEND</button><div id="log"></div></div>
<div class="board"><h3>SETTINGS</h3><label>Wake Word: <input id="wake" value="hey pico"></label><br><br><label>Personality: <select id="personality"><option>friendly</option><option>formal</option><option>witty</option><option>creative</option><option>wise</option></select></label><br><br><label>AI Provider: <select id="ai_provider"><option>deepseek</option><option>openai</option><option>anthropic</option><option>gemini</option><option>groq</option><option>ollama</option><option>custom</option></select></label><br><br><button onclick="saveSettings()">SAVE</button></div>
<div class="board"><h3>VOICEPRINTS</h3><div id="voiceprints">loading...</div></div>
<script>
async function refresh(){let r=await fetch('/api/status');let j=await r.json();document.getElementById('status').innerText=j.online?'ONLINE':'OFFLINE';document.getElementById('provider').innerText=j.provider;document.getElementById('budget').innerText=JSON.stringify(j.budget);document.getElementById('uptime').innerText=Math.floor(j.uptime)+'s';document.getElementById('voiceprints').innerText=j.voiceprints.join(', ')||'none';}
async function sendChat(){let txt=document.getElementById('msg').value;if(!txt)return;let log=document.getElementById('log');log.innerHTML+='<div>> '+txt+'</div>';let r=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:txt,user_id:'web'})});let j=await r.json();log.innerHTML+='<div style="color:#0f0">PICO: '+j.text+'</div>';log.scrollTop=log.scrollHeight;document.getElementById('msg').value='';}
async function saveSettings(){let data={wake_word:document.getElementById('wake').value,personality:document.getElementById('personality').value,ai_provider:document.getElementById('ai_provider').value};await fetch('/api/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});alert('Saved!');}
setInterval(refresh,3000);refresh();
</script></body></html>
'''

@app.get("/api/status")
async def get_status():
    global pico_core
    uptime = time.time() - start_time
    provider = pico_core.ai.default_provider_name if pico_core else "deepseek"
    from utils.budget import budget
    from utils.voiceprint_store import VoiceprintStore
    vstore = VoiceprintStore()
    return {"online": True, "version": "1.0.0", "uptime": uptime, "provider": provider, "voiceprints": vstore.list_users(), "budget": budget.report(), "latency": {}}

@app.post("/api/chat")
async def chat_endpoint(req: ChatRequest):
    global pico_core
    start = time.time()
    if pico_core:
        response = pico_core.ai.chat(req.text, user_id=req.user_id, provider_name=req.provider, personality=req.personality)
    else:
        response = f"[STANDALONE MOCK] You said: {req.text}"
    latency = (time.time()-start)*1000
    return {"text": response, "provider": req.provider or "default", "latency_ms": latency, "tokens": {}}

@app.post("/api/pair")
async def pair_device(req: PairingRequest, request: Request):
    client_ip = request.client.host
    ok, msg = pairing_manager.pair(req.device_key, client_ip)
    if not ok:
        raise HTTPException(status_code=403, detail=msg)
    return {"ok": True, "message": msg}

@app.post("/api/settings")
async def update_settings(settings: SettingsUpdate):
    global pico_core
    if pico_core and settings.ai_provider:
        pico_core.ai.switch_provider(settings.ai_provider)
    return {"ok": True}

@app.get("/api/history")
async def get_history(user_id: str = "guest"):
    global pico_core
    if pico_core:
        return {"history": pico_core.memory.get_history(user_id)}
    return {"history": []}

@app.get("/api/usage")
async def get_usage():
    from utils.token_tracker import tracker
    return tracker.summary()

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await ws_manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            msg = json.loads(data) if data.startswith("{") else {"type":"text","data":data}
            await websocket.send_text(json.dumps({"type":"chat","text": f"PICO heard: {msg.get('data', data)}"}))
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)

def set_core(core):
    global pico_core
    pico_core = core

def run_server(core=None, host="0.0.0.0", port=8765):
    global pico_core
    pico_core = core
    import uvicorn
    uvicorn.run(app, host=host, port=port)
