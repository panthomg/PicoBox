
from pydantic import BaseModel
from typing import Optional, List
class ChatRequest(BaseModel):
    user_id: str = "guest"
    text: str
    provider: Optional[str] = None
    personality: Optional[str] = None
class ChatResponse(BaseModel):
    text: str
    provider: str
    latency_ms: float
    tokens: dict
class DeviceStatus(BaseModel):
    online: bool
    version: str
    uptime: float
    provider: str
    voiceprints: List[str]
    budget: dict
    latency: dict
class PairingRequest(BaseModel):
    device_key: str
    wifi_ssid: str
    phone_ip: str
class SettingsUpdate(BaseModel):
    wake_word: Optional[str] = None
    tts_voice: Optional[str] = None
    personality: Optional[str] = None
    ai_provider: Optional[str] = None
    ai_model: Optional[str] = None
    daily_budget: Optional[float] = None
