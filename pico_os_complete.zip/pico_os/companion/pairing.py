
import secrets, json, time, socket
from pathlib import Path
from utils.logger import get_logger
class PairingManager:
    def __init__(self, key_path="data/device_key.json"):
        self.path = Path(key_path)
        if not self.path.is_absolute():
            # try relative to project
            if not self.path.exists():
                alt = Path("/mnt/data/pico_os") / key_path
                if alt.exists():
                    self.path = alt
        self.logger = get_logger("Pairing")
        self.device_key = self._load_or_create_key()
    def _load_or_create_key(self):
        if self.path.exists():
            try:
                data = json.loads(self.path.read_text())
                return data["device_key"]
            except:
                pass
        key = secrets.token_urlsafe(32)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps({"device_key": key, "created": time.time(), "paired_devices":[]}))
        self.logger.info(f"New device key {key[:8]}...")
        return key
    def verify_wifi_pairing(self, phone_ip, device_ip=None):
        try:
            if not device_ip:
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                s.connect(("8.8.8.8", 80))
                device_ip = s.getsockname()[0]
                s.close()
            dev_subnet = ".".join(device_ip.split(".")[:3])
            phone_subnet = ".".join(phone_ip.split(".")[:3])
            return dev_subnet == phone_subnet
        except:
            return True
    def pair(self, provided_key, phone_ip):
        if provided_key != self.device_key:
            return False, "Invalid device key"
        if not self.verify_wifi_pairing(phone_ip):
            return False, "Must be same Wi-Fi"
        try:
            data = json.loads(self.path.read_text())
            data["paired_devices"].append({"ip": phone_ip, "paired_at": time.time()})
            self.path.write_text(json.dumps(data, indent=2))
        except:
            pass
        return True, "Paired"
