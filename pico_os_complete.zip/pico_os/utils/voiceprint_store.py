
from pathlib import Path
import json, time
class VoiceprintStore:
    def __init__(self, base_dir="data/voiceprints"):
        self.base = Path(base_dir)
        self.base.mkdir(parents=True, exist_ok=True)
    def list_users(self):
        return [p.stem for p in self.base.glob("*.json")]
    def save_profile(self, user_id, embedding, samples=1):
        path = self.base / f"{user_id}.json"
        data = {"user_id": user_id, "embedding": embedding, "samples": samples, "updated": time.time()}
        path.write_text(json.dumps(data))
    def load_profile(self, user_id):
        path = self.base / f"{user_id}.json"
        if path.exists():
            return json.loads(path.read_text())
        return None
