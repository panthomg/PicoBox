
import time
from pathlib import Path
class BudgetManager:
    def __init__(self, daily_limit_inr=50, monthly_limit_inr=500, path="data/memory/budget.json"):
        self.daily_limit = daily_limit_inr
        self.monthly_limit = monthly_limit_inr
        self.path = Path(path)
        self.spent_today = 0
        self.spent_month = 0
    def can_spend(self, amount):
        return (self.spent_today + amount <= self.daily_limit) and (self.spent_month + amount <= self.monthly_limit)
    def spend(self, amount):
        self.spent_today += amount
        self.spent_month += amount
    def report(self):
        return {"daily": self.spent_today, "daily_limit": self.daily_limit, "monthly": self.spent_month, "monthly_limit": self.monthly_limit}
budget = BudgetManager()
