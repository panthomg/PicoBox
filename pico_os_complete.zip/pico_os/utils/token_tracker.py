
import json, time
from pathlib import Path
from collections import defaultdict
class TokenTracker:
    def __init__(self, path="data/memory/usage.json"):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.data = {"total_tokens":0, "by_provider": defaultdict(int), "history":[]}
        if self.path.exists():
            try:
                import json as js
                self.data = js.loads(self.path.read_text())
                self.data["by_provider"] = defaultdict(int, self.data.get("by_provider", {}))
            except: pass
    def add(self, provider, model, prompt_tokens, completion_tokens, cost_inr=0):
        self.data["total_tokens"] += prompt_tokens+completion_tokens
        self.data["by_provider"][provider] += prompt_tokens+completion_tokens
        self.data["history"].append({"ts": time.time(),"provider": provider,"model": model,"prompt": prompt_tokens,"completion": completion_tokens,"cost_inr": cost_inr})
        self._save()
    def _save(self):
        d = dict(self.data)
        d["by_provider"] = dict(d["by_provider"])
        self.path.write_text(__import__("json").dumps(d, indent=2))
    def summary(self):
        return self.data
tracker = TokenTracker()
