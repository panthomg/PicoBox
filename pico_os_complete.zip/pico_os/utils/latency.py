
import time
from collections import defaultdict
class LatencyTracker:
    def __init__(self):
        self.marks = {}
        self.stats = defaultdict(list)
    def mark(self, name):
        self.marks[name] = time.time()
    def measure(self, start, end):
        if start in self.marks and end in self.marks:
            delta = (self.marks[end]-self.marks[start])*1000
            self.stats[f"{start}->{end}"].append(delta)
            return delta
        return None
    def report(self):
        return {k: {"avg": sum(v)/len(v), "last": v[-1], "count": len(v)} for k,v in self.stats.items()}
tracker = LatencyTracker()
