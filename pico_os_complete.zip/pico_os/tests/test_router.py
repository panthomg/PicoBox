
from core.router import CommandRouter
def test_router():
    r = CommandRouter({"think_keywords":["think"],"search_keywords":["search"],"think_search_keywords":["search and think"]})
    assert r.route("think about black holes")[0]=="think"
    assert r.route("search weather")[0]=="search"
    assert r.route("search and think about quantum")[0]=="think_and_search"
    assert r.route("turn on lights")[0]=="action"
    assert r.route("what is life?")[0]=="chat"
    print("Router OK")
if __name__=="__main__":
    test_router()
