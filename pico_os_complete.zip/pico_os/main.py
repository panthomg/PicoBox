#!/usr/bin/env python3
"""
PICO OS - Complete Voice AI Assistant OS
"For those who ask. For those who question."
Built for Arduino UNO Q, runnable anywhere.
"""
import os, sys, threading
from pathlib import Path
try:
    from dotenv import load_dotenv
    load_dotenv()
except:
    pass

try:
    import yaml
except:
    # fallback minimal yaml parser for this config
    yaml = None

config_path = Path("config/config.yaml")
if not config_path.exists():
    config_path = Path("/mnt/data/pico_os/config/config.yaml")

if yaml:
    with open(config_path) as f:
        CONFIG = yaml.safe_load(f)
else:
    # minimal manual config if yaml not available
    CONFIG = {
        "audio": {"sample_rate": 16000, "frame_length": 512},
        "wake_word": {"keywords": ["hey pico", "pico"]},
        "speaker_verification": {"voiceprints_dir": "data/voiceprints"},
        "stt": {"model_path": "models/vosk"},
        "tts": {"model": "en_US-lessac-medium", "model_path": "models/piper/"},
        "router": {"think_keywords": ["think"], "search_keywords": ["search"], "think_search_keywords": ["search and think"]},
        "memory": {"max_conversation_turns": 20, "long_term_memory_file": "data/memory/long_term.json"},
        "interrupt": {"enabled": True, "barge_in_threshold_db": -40},
        "ai": {"default_provider": "deepseek", "default_model": "deepseek-chat", "temperature": 0.7, "max_tokens": 1024, "system_prompt_profile": "friendly", "providers": {}},
        "companion": {"host": "0.0.0.0", "port": 8765}
    }

MOCK_MODE = os.getenv("PICO_MOCK", "auto") == "true" or not os.getenv("PICOVOICE_ACCESS_KEY")

print("="*60)
print(" PICO OS v1.0 - Arduino UNO Q Edition")
print(" For those who ask. For those who question.")
print("="*60)
print(f" Config: {config_path}")
print(f" Mock Mode: {MOCK_MODE}")
print(f" Default AI: {CONFIG['ai']['default_provider']} / {CONFIG['ai']['default_model']}")
print("="*60)

from utils.logger import get_logger
logger = get_logger("Main")

from core.audio_io import AudioIO
from core.wake_word import WakeWordDetector
from core.speaker_verification import SpeakerVerifier
from core.stt import SpeechToText
from core.tts import TextToSpeech
from core.router import get_router
from core.memory import get_memory
from core.interrupter import SmartInterrupter
from core.lifecycle import PicoLifecycle
from ai.manager import AIManager
from services.search_service import SearchService
from services.spotify import SpotifyService
from services.youtube import YouTubeService
from services.smart_home.mqtt_client import MQTTService
from services.smart_home.wiz import WizService
from services.smart_home.matter import MatterService
from services.telephony.lte_module import LTEService
from services.telephony.voip import VoIPService
from services.telephony.agora_receptionist import AgoraReceptionist
from companion.pairing import PairingManager
try:
    from companion.server import set_core, run_server
    HAS_SERVER = True
except Exception as e:
    print(f"Companion server not available (install fastapi): {e}")
    HAS_SERVER = False
    def set_core(x): pass
    def run_server(*args, **kwargs): 
        print("Server mock - install requirements.txt for full companion app")

def build_system(mock=MOCK_MODE):
    logger.info("Initializing PICO subsystems...")
    audio_io = AudioIO(sample_rate=CONFIG["audio"]["sample_rate"], frame_length=CONFIG["audio"]["frame_length"], mock=mock)
    wake_word = WakeWordDetector(CONFIG["wake_word"], mock=mock)
    speaker = SpeakerVerifier(CONFIG["speaker_verification"], mock=True)
    stt = SpeechToText(CONFIG["stt"], mock=mock)
    tts = TextToSpeech(CONFIG["tts"], mock=mock)
    router = get_router(CONFIG["router"])
    memory = get_memory(CONFIG["memory"])
    ai_manager = AIManager(CONFIG["ai"], memory, mock=mock)

    search_svc = SearchService(mock=mock)
    spotify_svc = SpotifyService(mock=True)
    youtube_svc = YouTubeService(mock=True)
    mqtt_svc = MQTTService(mock=True)
    wiz_svc = WizService(mock=True)
    matter_svc = MatterService(mock=True)
    lte_svc = LTEService(mock=True)
    voip_svc = VoIPService(mock=True)
    agora_svc = AgoraReceptionist(mock=True)

    services = {
        "search": search_svc,
        "spotify": spotify_svc,
        "youtube": youtube_svc,
        "smart_home": mqtt_svc,
        "mqtt": mqtt_svc,
        "wiz": wiz_svc,
        "matter": matter_svc,
        "lte": lte_svc,
        "voip": voip_svc,
        "agora": agora_svc
    }

    interrupter = SmartInterrupter(CONFIG["interrupt"], audio_io, wake_word)
    pairing = PairingManager()
    lifecycle = PicoLifecycle(audio_io, wake_word, speaker, stt, tts, router, memory, ai_manager, services, interrupter, CONFIG)
    return lifecycle, pairing

def main():
    import argparse
    parser = argparse.ArgumentParser(description="PICO OS")
    parser.add_argument("--mock", action="store_true", help="Force mock mode")
    parser.add_argument("--no-server", action="store_true", help="Don't start companion web server")
    parser.add_argument("--text", type=str, help="Direct text command for testing")
    parser.add_argument("--onboard", action="store_true", help="Run voice-guided onboarding")
    args = parser.parse_args()

    mock = MOCK_MODE or args.mock
    lifecycle, pairing = build_system(mock=mock)

    if not args.no_server:
        set_core(lifecycle)
        server_thread = threading.Thread(target=run_server, kwargs={"core": lifecycle, "host": CONFIG["companion"]["host"], "port": CONFIG["companion"]["port"]}, daemon=True)
        server_thread.start()
        logger.info(f"Companion server started at http://{CONFIG['companion']['host']}:{CONFIG['companion']['port']}")
        print(f"\n Companion App: http://localhost:{CONFIG['companion']['port']} \n Device Key: {pairing.device_key} \n")

    if args.onboard:
        from onboarding.voice_guided import VoiceGuidedOnboarding
        onboarding = VoiceGuidedOnboarding(lifecycle.tts, lifecycle.audio, lifecycle.speaker, pairing)
        onboarding.run()

    if args.text:
        resp = lifecycle.handle_text_input("owner", args.text)
        print(resp)
        import time
        time.sleep(2)
        print(lifecycle.memory.get_history("owner"))
        return

    try:
        lifecycle.start()
    except KeyboardInterrupt:
        lifecycle.stop()
        print("\nPICO OS stopped. Bye!")

if __name__ == "__main__":
    main()
