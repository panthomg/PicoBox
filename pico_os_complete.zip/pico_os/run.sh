#!/bin/bash
pip install -q -r requirements.txt
python main.py --mock
