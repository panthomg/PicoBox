
from abc import ABC, abstractmethod
class AIProvider(ABC):
    def __init__(self, config, api_key=None):
        self.config = config
        self.api_key = api_key
    @abstractmethod
    def chat(self, messages, system_prompt="", temperature=0.7, max_tokens=1024):
        pass
    def estimate_cost_inr(self, prompt_tokens, completion_tokens):
        return (prompt_tokens*0.000012 + completion_tokens*0.000024)
