
from .provider_base import AIProvider
import os
from utils.logger import get_logger
class OpenAIProvider(AIProvider):
    def __init__(self, config, api_key=None):
        super().__init__(config, api_key)
        self.model = config.get("model", "gpt-4o-mini")
        self.base_url = config.get("base_url")
        self.logger = get_logger("OpenAI")
    def chat(self, messages, system_prompt="", temperature=0.7, max_tokens=1024):
        key = self.api_key or os.getenv("OPENAI_API_KEY")
        if not key:
            return {"text": f"[MOCK OpenAI] Response to: {messages[-1]['content'][:120]}", "prompt_tokens":10, "completion_tokens":20, "cost_inr":0.02}
        try:
            from openai import OpenAI
            client = OpenAI(api_key=key, base_url=self.base_url) if self.base_url else OpenAI(api_key=key)
            msgs = ([{"role":"system","content": system_prompt}] if system_prompt else []) + messages
            resp = client.chat.completions.create(model=self.model, messages=msgs, temperature=temperature, max_tokens=max_tokens)
            text = resp.choices[0].message.content
            usage = resp.usage
            return {"text": text, "prompt_tokens": usage.prompt_tokens if usage else 0, "completion_tokens": usage.completion_tokens if usage else 0, "cost_inr": self.estimate_cost_inr(usage.prompt_tokens if usage else 0, usage.completion_tokens if usage else 0)}
        except Exception as e:
            self.logger.error(f"OpenAI error {e}")
            return {"text": f"OpenAI error: {e}", "prompt_tokens":0, "completion_tokens":0, "cost_inr":0}
