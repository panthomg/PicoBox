
from .provider_base import AIProvider
import os
from utils.logger import get_logger
class AnthropicProvider(AIProvider):
    def __init__(self, config, api_key=None):
        super().__init__(config, api_key)
        self.model = config.get("model", "claude-3-5-sonnet-20241022")
        self.logger = get_logger("Anthropic")
    def chat(self, messages, system_prompt="", temperature=0.7, max_tokens=1024):
        key = self.api_key or os.getenv("ANTHROPIC_API_KEY")
        if not key:
            return {"text": f"[MOCK Claude] Answer to: {messages[-1]['content'][:120]}", "prompt_tokens":15, "completion_tokens":30, "cost_inr":0.05}
        try:
            import anthropic
            client = anthropic.Anthropic(api_key=key)
            resp = client.messages.create(model=self.model, system=system_prompt or "You are Pico.", messages=[{"role": m["role"], "content": m["content"]} for m in messages if m["role"]!="system"], temperature=temperature, max_tokens=max_tokens)
            text = resp.content[0].text
            return {"text": text, "prompt_tokens": resp.usage.input_tokens, "completion_tokens": resp.usage.output_tokens, "cost_inr": self.estimate_cost_inr(resp.usage.input_tokens, resp.usage.output_tokens)}
        except Exception as e:
            self.logger.error(f"Anthropic error {e}")
            return {"text": f"Claude error: {e}", "prompt_tokens":0, "completion_tokens":0, "cost_inr":0}
