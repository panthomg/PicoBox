
from .provider_base import AIProvider
import requests
from utils.logger import get_logger
class CustomProvider(AIProvider):
    def __init__(self, config, api_key=None):
        super().__init__(config, api_key)
        self.base_url = config.get("base_url", "http://localhost:8001/v1")
        self.model = config.get("model", "custom")
        self.logger = get_logger("CustomAI")
    def chat(self, messages, system_prompt="", temperature=0.7, max_tokens=1024):
        try:
            headers = {"Content-Type":"application/json"}
            if self.api_key:
                headers["Authorization"] = f"Bearer {self.api_key}"
            payload = {"model": self.model, "messages": ([{"role":"system","content": system_prompt}] if system_prompt else []) + messages, "temperature": temperature, "max_tokens": max_tokens}
            resp = requests.post(f"{self.base_url}/chat/completions", json=payload, headers=headers, timeout=30)
            resp.raise_for_status()
            data = resp.json()
            text = data["choices"][0]["message"]["content"]
            usage = data.get("usage", {})
            return {"text": text, "prompt_tokens": usage.get("prompt_tokens",0), "completion_tokens": usage.get("completion_tokens",0), "cost_inr":0}
        except Exception as e:
            self.logger.error(f"Custom error {e}")
            return {"text": f"Custom endpoint error: {e}", "prompt_tokens":0, "completion_tokens":0, "cost_inr":0}
