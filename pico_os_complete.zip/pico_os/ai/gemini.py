
from .provider_base import AIProvider
import os
from utils.logger import get_logger
class GeminiProvider(AIProvider):
    def __init__(self, config, api_key=None):
        super().__init__(config, api_key)
        self.model_name = config.get("model", "gemini-1.5-flash")
        self.logger = get_logger("Gemini")
    def chat(self, messages, system_prompt="", temperature=0.7, max_tokens=1024):
        key = self.api_key or os.getenv("GOOGLE_API_KEY")
        if not key:
            return {"text": f"[MOCK Gemini] Answer: {messages[-1]['content'][:120]}", "prompt_tokens":10, "completion_tokens":20, "cost_inr":0.01}
        try:
            import google.generativeai as genai
            genai.configure(api_key=key)
            model = genai.GenerativeModel(self.model_name, system_instruction=system_prompt)
            history_text = "\n".join([f"{m['role']}: {m['content']}" for m in messages])
            resp = model.generate_content(history_text, generation_config={"temperature": temperature, "max_output_tokens": max_tokens})
            text = resp.text
            return {"text": text, "prompt_tokens": len(history_text)//4, "completion_tokens": len(text)//4, "cost_inr": self.estimate_cost_inr(len(history_text)//4, len(text)//4)}
        except Exception as e:
            self.logger.error(f"Gemini error {e}")
            return {"text": f"Gemini error: {e}", "prompt_tokens":0, "completion_tokens":0, "cost_inr":0}
