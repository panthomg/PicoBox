
from .provider_base import AIProvider
import requests, os
from utils.logger import get_logger
class OllamaProvider(AIProvider):
    def __init__(self, config, api_key=None):
        super().__init__(config, api_key)
        self.base_url = config.get("base_url", os.getenv("OLLAMA_BASE_URL", "http://localhost:11434"))
        self.model = config.get("model", "llama3.1:8b")
        self.logger = get_logger("Ollama")
    def chat(self, messages, system_prompt="", temperature=0.7, max_tokens=1024):
        try:
            payload = {"model": self.model, "messages": ([{"role":"system","content": system_prompt}] if system_prompt else []) + messages, "stream": False, "options": {"temperature": temperature, "num_predict": max_tokens}}
            resp = requests.post(f"{self.base_url}/api/chat", json=payload, timeout=60)
            if resp.status_code != 200:
                raise Exception(resp.text[:200])
            data = resp.json()
            text = data["message"]["content"]
            return {"text": text, "prompt_tokens": data.get("prompt_eval_count", 10), "completion_tokens": data.get("eval_count", 20), "cost_inr": 0.0}
        except Exception as e:
            self.logger.warning(f"Ollama mock: {e}")
            return {"text": f"[MOCK Ollama local] Local answer to: {messages[-1]['content'][:150]}. Cost ₹0!", "prompt_tokens":10, "completion_tokens":20, "cost_inr":0.0}
