
from utils.logger import get_logger
from utils.token_tracker import tracker as token_tracker
from utils.budget import budget
from pathlib import Path
import yaml
class AIManager:
    def __init__(self, config, memory, mock=False):
        self.config = config
        self.memory = memory
        self.mock = mock
        self.logger = get_logger("AIManager")
        self.providers = {}
        self.personalities = self._load_personalities()
        self.default_provider_name = config.get("default_provider", "deepseek")
        self._init_providers()
    def _load_personalities(self):
        ppath = Path("config/personalities.yaml")
        if not ppath.exists():
            ppath = Path("/mnt/data/pico_os/config/personalities.yaml")
        if ppath.exists():
            return yaml.safe_load(ppath.read_text())
        return {"friendly": {"system_prompt": "You are Pico."}}
    def _init_providers(self):
        cfg = self.config.get("providers", {})
        try:
            from .deepseek import DeepSeekProvider
            self.providers["deepseek"] = DeepSeekProvider(cfg.get("deepseek", {}))
        except Exception as e:
            self.logger.warning(f"DeepSeek fail {e}")
        try:
            from .openai_provider import OpenAIProvider
            self.providers["openai"] = OpenAIProvider(cfg.get("openai", {}))
        except Exception as e:
            self.logger.warning(f"OpenAI fail {e}")
        try:
            from .anthropic import AnthropicProvider
            self.providers["anthropic"] = AnthropicProvider(cfg.get("anthropic", {}))
        except: pass
        try:
            from .gemini import GeminiProvider
            self.providers["gemini"] = GeminiProvider(cfg.get("gemini", {}))
        except: pass
        try:
            from .groq import GroqProvider
            self.providers["groq"] = GroqProvider(cfg.get("groq", {}))
        except: pass
        try:
            from .ollama import OllamaProvider
            self.providers["ollama"] = OllamaProvider(cfg.get("ollama", {}))
        except: pass
        try:
            from .custom import CustomProvider
            self.providers["custom"] = CustomProvider(cfg.get("custom", {}))
        except: pass
    def _get_provider(self, name=None):
        name = name or self.default_provider_name
        return self.providers.get(name) or self.providers.get("deepseek") or list(self.providers.values())[0]
    def chat(self, query, user_id="guest", context=None, mode="chat", provider_name=None, personality=None):
        if not budget.can_spend(0.1):
            return "Budget limit reached. Switch to Ollama (free) or increase limit in companion app."
        personality_name = personality or self.config.get("system_prompt_profile", "friendly")
        sys_prompt = self.personalities.get(personality_name, {}).get("system_prompt", "You are Pico.")
        if context:
            sys_prompt += f"\n\nWeb search context:\n{context}\nUse context."
        history = self.memory.get_history(user_id, n=6)
        messages = history + [{"role":"user","content": query}]
        provider = self._get_provider(provider_name)
        result = provider.chat(messages, system_prompt=sys_prompt, temperature=self.config.get("temperature",0.7), max_tokens=self.config.get("max_tokens",1024))
        token_tracker.add(provider_name or self.default_provider_name, getattr(provider,'model','unknown'), result.get("prompt_tokens",0), result.get("completion_tokens",0), result.get("cost_inr",0))
        budget.spend(result.get("cost_inr",0))
        return result["text"]
    def switch_provider(self, name):
        if name in self.providers:
            self.default_provider_name = name
            return True
        return False
