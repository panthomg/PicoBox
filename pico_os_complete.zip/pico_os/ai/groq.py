
from .provider_base import AIProvider
import os
from utils.logger import get_logger
class GroqProvider(AIProvider):
    def __init__(self, config, api_key=None):
        super().__init__(config, api_key)
        self.model = config.get("model", "llama-3.1-70b-versatile")
        self.logger = get_logger("Groq")
    def chat(self, messages, system_prompt="", temperature=0.7, max_tokens=1024):
        key = self.api_key or os.getenv("GROQ_API_KEY")
        if not key:
            return {"text": f"[MOCK Groq fast] {messages[-1]['content'][:120]} -> instant!", "prompt_tokens":8, "completion_tokens":16, "cost_inr":0.005}
        try:
            from groq import Groq
            client = Groq(api_key=key)
            msgs = ([{"role":"system","content": system_prompt}] if system_prompt else []) + messages
            resp = client.chat.completions.create(model=self.model, messages=msgs, temperature=temperature, max_tokens=max_tokens)
            text = resp.choices[0].message.content
            return {"text": text, "prompt_tokens": resp.usage.prompt_tokens, "completion_tokens": resp.usage.completion_tokens, "cost_inr": self.estimate_cost_inr(resp.usage.prompt_tokens, resp.usage.completion_tokens)}
        except Exception as e:
            self.logger.error(f"Groq error {e}")
            return {"text": f"Groq error: {e}", "prompt_tokens":0, "completion_tokens":0, "cost_inr":0}
