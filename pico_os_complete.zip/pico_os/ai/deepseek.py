
from .provider_base import AIProvider
import requests, os
from utils.logger import get_logger
class DeepSeekProvider(AIProvider):
    def __init__(self, config, api_key=None):
        super().__init__(config, api_key)
        self.base_url = config.get("base_url", "https://api.deepseek.com/v1")
        self.model = config.get("model", "deepseek-chat")
        self.logger = get_logger("DeepSeek")
    def chat(self, messages, system_prompt="", temperature=0.7, max_tokens=1024):
        import os
        key = self.api_key or os.getenv("DEEPSEEK_API_KEY")
        if not key:
            return {"text": f"[MOCK DeepSeek] I would answer: {messages[-1]['content'][:100]}", "prompt_tokens": 10, "completion_tokens": 20, "cost_inr": 0.01}
        headers = {"Authorization": f"Bearer {key}", "Content-Type":"application/json"}
        payload = {"model": self.model, "messages": ([{"role":"system","content": system_prompt}] if system_prompt else []) + messages, "temperature": temperature, "max_tokens": max_tokens}
        try:
            resp = requests.post(f"{self.base_url}/chat/completions", json=payload, headers=headers, timeout=30)
            resp.raise_for_status()
            data = resp.json()
            text = data["choices"][0]["message"]["content"]
            usage = data.get("usage", {})
            return {"text": text, "prompt_tokens": usage.get("prompt_tokens",0), "completion_tokens": usage.get("completion_tokens",0), "cost_inr": self.estimate_cost_inr(usage.get("prompt_tokens",0), usage.get("completion_tokens",0))}
        except Exception as e:
            self.logger.error(f"DeepSeek error {e}")
            return {"text": f"DeepSeek error: {e}", "prompt_tokens":0, "completion_tokens":0, "cost_inr":0}
